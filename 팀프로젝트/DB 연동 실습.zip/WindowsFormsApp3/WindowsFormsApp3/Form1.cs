﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        string connect_info = "DATA SOURCE = xe; User Id = sqlDB; password = 1234;";
        OracleConnection conn;
        OracleCommand comm;
        OracleDataAdapter adt;
        DataSet data = new DataSet();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
            DataSet data = new DataSet();
            string sql = "SELECT * FROM BUYTBL3";            
            conn = new OracleConnection(connect_info);
            conn.Open();
            adt = new OracleDataAdapter(sql, conn);
            adt.Fill(data);
            dataGridView1.DataSource = data.Tables[0];
            
            conn.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string prodName = string.Format(textBox3.Text);
            string userName = string.Format(textBox2.Text);
            string sql = "INSERT INTO BUYTBL3 VALUES ('"+ userName + "','" + prodName + "')";
            conn = new OracleConnection(connect_info);
            conn.Open();
            comm = new OracleCommand(sql, conn);
            comm.ExecuteNonQuery();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string userName = string.Format(textBox4.Text);
            DataSet data = new DataSet();
            string sql = "SELECT * FROM BUYTBL3 WHERE USERID ='" + userName + "'";
            conn = new OracleConnection(connect_info);
            conn.Open();
            adt = new OracleDataAdapter(sql, conn);
            adt.Fill(data);
            dataGridView1.DataSource = data.Tables[0];

            conn.Close();
        }
    }
}
