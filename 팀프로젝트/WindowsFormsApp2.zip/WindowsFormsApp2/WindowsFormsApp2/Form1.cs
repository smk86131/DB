﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1() => InitializeComponent();

        OleDbConnection con = new OleDbConnection("Provider=OraOLEDB.Oracle.1;Data Source=XE;User ID=sqlDB;Password=1234;Unicode=True");
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbDataAdapter oda = new OleDbDataAdapter("select * from userTBL", con);
            DataTable dt = new DataTable();
            oda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lblText.Text = "처음으로 작성해보는 \nASP.NET 페이지";
        }
    }
}
