﻿
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.업주번호DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.업주이름DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.사업자번호DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.업주주민등록번호DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.핸드폰번호DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.업주이메일DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.업주BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new WindowsFormsApp1.DataSet1();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataSet2 = new WindowsFormsApp1.DataSet2();
            this.dataSet2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet2BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.고객BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.고객TableAdapter = new WindowsFormsApp1.DataSet2TableAdapters.고객TableAdapter();
            this.고객BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.고객TableAdapter1 = new WindowsFormsApp1.DataSet1TableAdapters.고객TableAdapter();
            this.사업장BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.사업장TableAdapter = new WindowsFormsApp1.DataSet1TableAdapters.사업장TableAdapter();
            this.고객BindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.사업장BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.사업장정보BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.사업장_정보TableAdapter = new WindowsFormsApp1.DataSet1TableAdapters.사업장_정보TableAdapter();
            this.업주TableAdapter = new WindowsFormsApp1.DataSet1TableAdapters.업주TableAdapter();
            this.예약내역BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.예약내역TableAdapter = new WindowsFormsApp1.DataSet1TableAdapters.예약내역TableAdapter();
            this.회사BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.회사TableAdapter = new WindowsFormsApp1.DataSet1TableAdapters.회사TableAdapter();
            this.dataSet1BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1BindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.사업장정보BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.업주BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet2BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.고객BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.고객BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.사업장BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.고객BindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.사업장BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.사업장정보BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.예약내역BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.회사BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.사업장정보BindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.업주번호DataGridViewTextBoxColumn,
            this.업주이름DataGridViewTextBoxColumn,
            this.사업자번호DataGridViewTextBoxColumn,
            this.업주주민등록번호DataGridViewTextBoxColumn,
            this.핸드폰번호DataGridViewTextBoxColumn,
            this.업주이메일DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.업주BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(70, 188);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(662, 181);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // 업주번호DataGridViewTextBoxColumn
            // 
            this.업주번호DataGridViewTextBoxColumn.DataPropertyName = "업주번호";
            this.업주번호DataGridViewTextBoxColumn.HeaderText = "업주번호";
            this.업주번호DataGridViewTextBoxColumn.Name = "업주번호DataGridViewTextBoxColumn";
            // 
            // 업주이름DataGridViewTextBoxColumn
            // 
            this.업주이름DataGridViewTextBoxColumn.DataPropertyName = "업주이름";
            this.업주이름DataGridViewTextBoxColumn.HeaderText = "업주이름";
            this.업주이름DataGridViewTextBoxColumn.Name = "업주이름DataGridViewTextBoxColumn";
            // 
            // 사업자번호DataGridViewTextBoxColumn
            // 
            this.사업자번호DataGridViewTextBoxColumn.DataPropertyName = "사업자번호";
            this.사업자번호DataGridViewTextBoxColumn.HeaderText = "사업자번호";
            this.사업자번호DataGridViewTextBoxColumn.Name = "사업자번호DataGridViewTextBoxColumn";
            // 
            // 업주주민등록번호DataGridViewTextBoxColumn
            // 
            this.업주주민등록번호DataGridViewTextBoxColumn.DataPropertyName = "업주주민등록번호";
            this.업주주민등록번호DataGridViewTextBoxColumn.HeaderText = "업주주민등록번호";
            this.업주주민등록번호DataGridViewTextBoxColumn.Name = "업주주민등록번호DataGridViewTextBoxColumn";
            // 
            // 핸드폰번호DataGridViewTextBoxColumn
            // 
            this.핸드폰번호DataGridViewTextBoxColumn.DataPropertyName = "핸드폰번호";
            this.핸드폰번호DataGridViewTextBoxColumn.HeaderText = "핸드폰번호";
            this.핸드폰번호DataGridViewTextBoxColumn.Name = "핸드폰번호DataGridViewTextBoxColumn";
            // 
            // 업주이메일DataGridViewTextBoxColumn
            // 
            this.업주이메일DataGridViewTextBoxColumn.DataPropertyName = "업주이메일";
            this.업주이메일DataGridViewTextBoxColumn.HeaderText = "업주이메일";
            this.업주이메일DataGridViewTextBoxColumn.Name = "업주이메일DataGridViewTextBoxColumn";
            // 
            // 업주BindingSource
            // 
            this.업주BindingSource.DataMember = "업주";
            this.업주BindingSource.DataSource = this.dataSet1BindingSource;
            // 
            // dataSet1BindingSource
            // 
            this.dataSet1BindingSource.DataSource = this.dataSet1;
            this.dataSet1BindingSource.Position = 0;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(657, 375);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 18;
            this.button3.Text = "초기화";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(374, 375);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 17;
            this.button2.Text = "삭제";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(70, 375);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 16;
            this.button1.Text = "입력/수정";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(179, 147);
            this.textBox3.MaxLength = 40;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(199, 21);
            this.textBox3.TabIndex = 15;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(179, 104);
            this.textBox2.MaxLength = 30;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(199, 21);
            this.textBox2.TabIndex = 14;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(179, 52);
            this.textBox1.MaxLength = 4;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(199, 21);
            this.textBox1.TabIndex = 13;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(68, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 12;
            this.label3.Text = "사업자번호";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(68, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 11;
            this.label2.Text = "업주이름";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(68, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 10;
            this.label1.Text = "업주번호";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // dataSet2
            // 
            this.dataSet2.DataSetName = "DataSet2";
            this.dataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataSet2BindingSource
            // 
            this.dataSet2BindingSource.DataSource = this.dataSet2;
            this.dataSet2BindingSource.Position = 0;
            // 
            // dataSet2BindingSource1
            // 
            this.dataSet2BindingSource1.DataSource = this.dataSet2;
            this.dataSet2BindingSource1.Position = 0;
            // 
            // 고객BindingSource
            // 
            this.고객BindingSource.DataMember = "고객";
            this.고객BindingSource.DataSource = this.dataSet2BindingSource1;
            // 
            // 고객TableAdapter
            // 
            this.고객TableAdapter.ClearBeforeFill = true;
            // 
            // 고객BindingSource1
            // 
            this.고객BindingSource1.DataMember = "고객";
            this.고객BindingSource1.DataSource = this.dataSet1BindingSource;
            // 
            // 고객TableAdapter1
            // 
            this.고객TableAdapter1.ClearBeforeFill = true;
            // 
            // 사업장BindingSource
            // 
            this.사업장BindingSource.DataMember = "사업장";
            this.사업장BindingSource.DataSource = this.dataSet1BindingSource;
            // 
            // 사업장TableAdapter
            // 
            this.사업장TableAdapter.ClearBeforeFill = true;
            // 
            // 고객BindingSource2
            // 
            this.고객BindingSource2.DataMember = "고객";
            this.고객BindingSource2.DataSource = this.dataSet1BindingSource;
            // 
            // 사업장BindingSource1
            // 
            this.사업장BindingSource1.DataMember = "사업장";
            this.사업장BindingSource1.DataSource = this.dataSet1BindingSource;
            // 
            // 사업장정보BindingSource
            // 
            this.사업장정보BindingSource.DataMember = "사업장_정보";
            this.사업장정보BindingSource.DataSource = this.dataSet1BindingSource;
            // 
            // 사업장_정보TableAdapter
            // 
            this.사업장_정보TableAdapter.ClearBeforeFill = true;
            // 
            // 업주TableAdapter
            // 
            this.업주TableAdapter.ClearBeforeFill = true;
            // 
            // 예약내역BindingSource
            // 
            this.예약내역BindingSource.DataMember = "예약내역";
            this.예약내역BindingSource.DataSource = this.dataSet1BindingSource;
            // 
            // 예약내역TableAdapter
            // 
            this.예약내역TableAdapter.ClearBeforeFill = true;
            // 
            // 회사BindingSource
            // 
            this.회사BindingSource.DataMember = "회사";
            this.회사BindingSource.DataSource = this.dataSet1BindingSource;
            // 
            // 회사TableAdapter
            // 
            this.회사TableAdapter.ClearBeforeFill = true;
            // 
            // dataSet1BindingSource1
            // 
            this.dataSet1BindingSource1.DataSource = this.dataSet1;
            this.dataSet1BindingSource1.Position = 0;
            // 
            // dataSet1BindingSource2
            // 
            this.dataSet1BindingSource2.DataSource = this.dataSet1;
            this.dataSet1BindingSource2.Position = 0;
            // 
            // 사업장정보BindingSource1
            // 
            this.사업장정보BindingSource1.DataMember = "사업장_정보";
            this.사업장정보BindingSource1.DataSource = this.dataSet1BindingSource1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(426, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 12);
            this.label4.TabIndex = 19;
            this.label4.Text = "업주주민등록번호";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(426, 107);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 20;
            this.label5.Text = "핸드폰번호";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(424, 156);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 21;
            this.label6.Text = "업주이메일";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(533, 52);
            this.textBox4.MaxLength = 4;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(199, 21);
            this.textBox4.TabIndex = 22;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(533, 101);
            this.textBox5.MaxLength = 4;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(199, 21);
            this.textBox5.TabIndex = 23;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(533, 153);
            this.textBox6.MaxLength = 4;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(199, 21);
            this.textBox6.TabIndex = 24;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.업주BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet2BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.고객BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.고객BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.사업장BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.고객BindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.사업장BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.사업장정보BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.예약내역BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.회사BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.사업장정보BindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.BindingSource dataSet1BindingSource;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource dataSet2BindingSource;
        private DataSet2 dataSet2;
        private System.Windows.Forms.BindingSource dataSet2BindingSource1;
        private System.Windows.Forms.BindingSource 고객BindingSource;
        private DataSet2TableAdapters.고객TableAdapter 고객TableAdapter;
        private System.Windows.Forms.BindingSource 고객BindingSource1;
        private DataSet1TableAdapters.고객TableAdapter 고객TableAdapter1;
        private System.Windows.Forms.BindingSource 사업장BindingSource;
        private DataSet1TableAdapters.사업장TableAdapter 사업장TableAdapter;
        private System.Windows.Forms.BindingSource 사업장BindingSource1;
        private System.Windows.Forms.BindingSource 고객BindingSource2;
        private System.Windows.Forms.BindingSource 사업장정보BindingSource;
        private DataSet1TableAdapters.사업장_정보TableAdapter 사업장_정보TableAdapter;
        private System.Windows.Forms.BindingSource 업주BindingSource;
        private DataSet1TableAdapters.업주TableAdapter 업주TableAdapter;
        private System.Windows.Forms.BindingSource 예약내역BindingSource;
        private DataSet1TableAdapters.예약내역TableAdapter 예약내역TableAdapter;
        private System.Windows.Forms.BindingSource 회사BindingSource;
        private DataSet1TableAdapters.회사TableAdapter 회사TableAdapter;
        private System.Windows.Forms.BindingSource dataSet1BindingSource1;
        private DataGridViewCellEventHandler dataGridView1_CellContentClick;
        private DataGridViewTextBoxColumn 업주번호DataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn 업주이름DataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn 사업자번호DataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn 업주주민등록번호DataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn 핸드폰번호DataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn 업주이메일DataGridViewTextBoxColumn;
        private BindingSource dataSet1BindingSource2;
        private BindingSource 사업장정보BindingSource1;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
    }
}

