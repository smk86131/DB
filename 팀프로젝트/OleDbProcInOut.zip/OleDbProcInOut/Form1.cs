﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1() => InitializeComponent();

        OleDbConnection con = new OleDbConnection("Provider=OraOLEDB.Oracle.1;Data Source=XE;User ID=sqlDB;Password=1234;Unicode=True");
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbDataAdapter oda = new OleDbDataAdapter("select * from userTBL", con);
            DataTable dt = new DataTable();
            oda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lblText.Text = "처음으로 작성해보는 \nASP.NET 페이지";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // dataGridView1.DataSource = getToDoList();
            string name = "이승기";
            if (!string.IsNullOrWhiteSpace(textBox1.Text))
                name = textBox1.Text;
            
            lblText.Text = getUserHeight(name).ToString();
        }

        public int getUserHeight(string userName)
        {
            int height = 0;

            string connString1 = "Provider=OraOLEDB.Oracle.1;Data Source=XE;User ID=sqlDB;Password=1234;Unicode=True";
            OleDbConnection conn = new OleDbConnection(connString1);

            try
            {
                conn.Open();
                using(OleDbCommand command = new OleDbCommand("GetUserHeight", conn))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    OleDbParameter p_in = new OleDbParameter("p_in", OleDbType.VarChar);
                    p_in.Direction = ParameterDirection.Input;
                    p_in.Value = userName;

                    OleDbParameter p_out = new OleDbParameter("p_out", OleDbType.Numeric);
                    p_out.Direction = ParameterDirection.Output;
                    p_out.Value = 0;

                    command.Parameters.Add(p_in);
                    command.Parameters.Add(p_out);

                    command.ExecuteNonQuery();
                    height = int.Parse(p_out.Value.ToString());
                    lblText.Text = height.ToString();
                }

            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }

            return height;
        }


        public DataTable getToDoList(string id)
        {
            string connString1 = "Provider=OraOLEDB.Oracle.1;Data Source=XE;User ID=sqlDB;Password=1234;Unicode=True"; // 'PLSQLRSet = 1' is important

            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            OleDbConnection conn = new OleDbConnection(connString1);
            OleDbCommand cmd = new OleDbCommand("getTodoList", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            try
            {
                conn.Open();

                OleDbParameter[] parms = {
                                         new OleDbParameter("id1", OleDbType  .VarChar)
                                     };
                parms[0].Value = id;
                parms[0].Direction = ParameterDirection.Input;
                foreach (OleDbParameter parm in parms)
                {
                    cmd.Parameters.Add(parm);
                }

                OleDbDataAdapter oda = new OleDbDataAdapter(cmd);

                oda.Fill(ds);

            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                conn.Close();
            }

            return ds.Tables[0];
        }

        private void lblText_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
